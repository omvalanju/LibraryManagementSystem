<?php

include("database_conn.php");

session_start();
 if(!isset($_SESSION['loggedin'])){
     echo('You Need To Login First!');
     header('refresh:2;url=login.php');
     
 }
  $people_id=$_SESSION['people_id'];

  $book_id=$_GET['book_id']; 
  $borrow_id=$_GET['borrow_id']; 
  $days_remaining=$_GET['days_remaining']*-1; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Debit Card Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter Debit Card Details</h2>
        <form  method="POST" action="book_return.php">
            <input name="book_id" value="<?php echo $book_id; ?>"  >
            <input name="borrow_id"  value="<?php echo $borrow_id; ?>" >
            <label for="cardNumber">Card Number</label>
            <input type="text" id="cardNumber" name="cardNumber" placeholder="1234 5678 9012 3456" maxlength="19" >

            <label for="cardName">Cardholder Name</label>
            <input type="text" id="cardName" name="cardName" placeholder="John Doe" >

            <label for="expiryDate">Expiry Date</label>
            <input type="month" id="expiryDate" name="expiryDate" >

            <label for="cvv">CVV</label>
            <input type="password" id="cvv" name="cvv" placeholder="123" maxlength="3" >

            <label for="amount">Amount to Pay</label>
            <input type="number" id="amount" name="amount" value="<?php echo $days_remaining *2; ?>" disabled>  

            

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
