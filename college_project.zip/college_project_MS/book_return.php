<?php

include("database_conn.php");

session_start();
 if(!isset($_SESSION['loggedin'])){
     echo('You Need To Login First!');
     header('refresh:2;url=login.php');
     
 }
   $people_id=$_SESSION['people_id'];

   $book_id=$_GET['book_id']; 
   $borrow_id=$_GET['borrow_id']; 
   $book_id=$_POST['book_id']; 
   $borrow_id=$_POST['borrow_id']; 

  $query2 = "SELECT * FROM `books` WHERE books.book_id = '".$book_id."'";
  $data2 = mysqli_query($conn, $query2);
  $result2 = mysqli_fetch_assoc($data2);
  $copies_available= $result2['copies_available']+1;

  $sql = "UPDATE `books` SET `copies_available`='$copies_available' WHERE books.book_id = $book_id";
 $sql1 = "UPDATE `borrow_records` SET `return_status`='returned' WHERE borrow_records.borrow_id = $borrow_id";



$data = mysqli_query($conn,$sql);
$data1 = mysqli_query($conn,$sql1);
if($data){
  ?>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <body class="w3-container w3-auto">

      <div class="w3-panel w3-green">
        <h3>Success!</h3>
        <p>You Successfully added DATA .</p>
      </div>    <?php
  header('refresh:2;url=dashboard.php');
}
else{
  ?>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <body class="w3-container">
  
  <div class="w3-panel w3-red">
    <h3>Danger!</h3>
    <p>Something Went Wrong</p>
  </div>
<?php
}