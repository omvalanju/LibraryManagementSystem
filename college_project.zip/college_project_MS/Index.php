<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>


$password = 'hashedpassword1';
echo  password_hash($password, PASSWORD_DEFAULT);


$hash = '$2y$10$r6EvwPHk/XqQaLdXVk181eZDhthyiqEMnOyJo6yi/6gfYscdW6FRO';
$valid = password_verify('hashedpassword1', $hash);

echo $valid ? 'Valid' : 'Not valid';