<?php
  include("database_conn.php");
  
       $fname=$_POST['fname'];
       $monnum=$_POST['mon_num'];
       $email=$_POST['email'];
       $address=$_POST['address'];
       date_default_timezone_set('Asia/Calcutta'); 
       $fvv = date('m/d/Y h:i:s a', time());

       
       $sql1="SELECT * FROM user_id WHERE email LIKE '$email'";
        $data=mysqli_query($conn,$sql1);
        $total=mysqli_num_rows($data);
        $sql2="SELECT * FROM user_id WHERE mo_num LIKE '$mon_num'";
        $data2=mysqli_query($conn,$sql2);
        $total2=mysqli_num_rows($data2);
       if($total>0){
            
            ?>
            <body style="background-color: rgb(0, 0, 36);">

            
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

            <div class="card text-center" style="margin-left:10%;margin-right:10%;margin-top:5%;">
            <div class="card-header">
              Featured
            </div>
            <div class="card-body">
              <h5 class="card-title">This <u style="color:red;"><?php echo $email?></u> Email exists already .</h5>
              <p class="card-text">This error message usually appears when a user enters an email address that has already been registered on the website or service.</p>
              <p class="card-text">In some cases, users might receive this error message even if they don't remember signing up for the service before. This could be due to several reasons, such as using a different email address or having someone else create an account using their email address.</p>
              <p class="card-text">To resolve this issue, users can try resetting their password using the "Forgot Password" feature or contacting the customer support team of the service to assist with their account access. They can also try using a different email address to create a new account.</p>
              <p class="card-text">In conclusion, "Email exists already" is an important error message that helps to maintain the integrity and security of user accounts by preventing multiple accounts from being created using the same email address.</p>

              <a href="regi_signup.php" class="btn btn-primary">BACK</a>
            </div>
            <div class="card-footer text-muted">
            There are several reasons why a Email might be considered invalid or incorrect. But <u>PLEASE CHANGE EMAIL</u>.
            </div>
                </div>
            </body>
                <?php
       }else if($total2>0){
        ?>
        <body style="background-color: rgb(0, 0, 36);">

        
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

        <div class="card text-center" style="margin-left:10%;margin-right:10%;margin-top:5%;">
        <div class="card-header">
          Featured
        </div>
        <div class="card-body">
          <h5 class="card-title">This <u style="color:red;"><?php echo $mon_num?></u> Mobile Number exists already .</h5>
          <p class="card-text">This message usually appears when the mobile number entered by the user has already been registered on the website or service.</p>
          <p class="card-text">The purpose of this error message is to prevent users from creating multiple accounts using the same mobile number. Having multiple accounts with the same mobile number can cause confusion and make it difficult for the user to manage their accounts. It can also create security risks, as hackers or malicious actors can gain unauthorized access to user accounts.</p>
          <p class="card-text">In some cases, users might receive this error message even if they don't remember signing up for the service before. This could be due to several reasons, such as using a different mobile number or having someone else create an account using their mobile number.</p>
          <p class="card-text">To resolve this issue, users can try resetting their password using the "Forgot Password" feature or contacting the customer support team of the service to assist with their account access. They can also try using a different mobile number to create a new account.</p>

          <a href="regi_signup.php" class="btn btn-primary">BACK</a>
        </div>
        <div class="card-footer text-muted">
        There are several reasons why a mobile number might be considered invalid or incorrect. But <u>PLEASE CHANGE NUMBER</u>.
        </div>
            </div>
        </body>
            <?php
       }else{
        $sql="INSERT INTO `users`(`Name`, `Email`,`Phone_Number` ,`Address`) VALUES ('$sc_name','$fname','$monnum','$email')";
        $data = mysqli_query($conn,$sql);
        
        if($data){
            ?>
            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
            <body class="w3-container w3-auto">

            <div class="w3-panel w3-green">
              <h3>Success!</h3>
              <p>Your AC Successfully added DATA .</p>
              <p>When you receive a message saying "your account is successfully created," it typically means that you have completed the registration process for a new account on a website or online platform. This message indicates that you can now log in to your account using the username and password you created during the registration process.</p>
              <p>Creating a new account is often necessary to access certain features or content on a website, such as making purchases, accessing exclusive content, or participating in online communities. It is important to follow the instructions provided during the account creation process carefully to ensure that your account is set up correctly and that you can easily access the features you need.</p>
              <p>Once you have created your account, it is a good idea to review the site's terms and conditions and privacy policy to understand how your information will be used and protected. You may also want to set up additional security features, such as two-factor authentication or a strong password, to ensure the security of your account.</p>
              <p>Overall, receiving a message that your account has been successfully created is an important milestone in the process of accessing online services, and it opens up a world of opportunities for online engagement and participation.</p>
            </div>    <?php		
            ///mkdir("name_folder/".$email);

            header('refresh:2;url=login.php');
        }
        else{?>
          <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
          <body class="w3-container">
        
          <div class="w3-panel w3-red">
            <h3>Danger!</h3>
            <p>Something Went Wrong</p>
          </div><?php
        }
   
   
       }
     
     

?>

