<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <style>
        /* Importing fonts from Google */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');

/* Reseting */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
    
}


.wrapper {
    max-width: 350px;
    min-height: 500px;
    margin: 80px auto;
    padding: 40px 30px 30px 30px;
    background-color: rgba(0, 0, 60, 0.8);
    border-radius: 15px;
    box-shadow: 1px 1px 1px #cbced1, -1px -1px 1px #fff;
}

.logo {
    width: 80px;
    margin: auto;
}

.logo img {
    width: 100%;
    height: 80px;
    object-fit: cover;
    border-radius: 20%;
    box-shadow: 0px 0px 1px #5f5f5f,
        0px 0px 0px 1px #ecf0f3,
        1px 1px 1px #a7aaa7,
        -1px -1px 1px #fff;
}

.wrapper .name {
    font-weight: 600;
    font-size: 1.4rem;
    letter-spacing: 1.3px;
    padding-left: 10px;
    color: white;
}

.wrapper .form-field input {
    width: 100%;
    display: block;
    border: none;
    outline: none;
    background: none;
    font-size: 1.2rem;
    color: white;
    padding: 10px 15px 10px 10px;
    /* border: 1px solid red; */
}

.wrapper .form-field {
    padding-left: 10px;
    margin-bottom: 20px;
    border-radius: 20px;
    box-shadow: inset 1px 1px 1px #cbced1, inset -1px -1px 1px #fff;
}

.wrapper .form-field .fas {
    color: white;
}

.wrapper .btn {
    box-shadow: none;
    width: 100%;
    height: 40px;
    background-color: #03A9F4;
    color: #fff;
    border-radius: 25px;
    box-shadow: 1px 1px 1px #b1b1b1,
        -1px -1px 1px #fff;
    letter-spacing: 1.3px;
}

.wrapper .btn:hover {
    background-color: #039BE5;
}

.wrapper a {
    text-decoration: none;
    font-size: 0.8rem;
    color: #03A9F4;
}

.wrapper a:hover {
    color: #039BE5;
}

@media(max-width: 380px) {
    .wrapper {
        margin: 30px 20px;
        padding: 40px 15px 15px 15px;
    }
}
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    
</head>
<body style="background-image: url('c.jpg');background-size: cover;">
    <div  class="wrapper">
        <div class="logo">
            <img src="img/black.png" alt="">
        </div>
        
        <div class="text-center mt-4 name">
            class project 
        </div>

        <form  action="new_login_auth.php" method="post" class="p-3 mt-3">
            
            <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
                <input type="email" name="email" id="email" placeholder="Email" required>
            </div>
            <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
                <input type="text" name="hash_pass" id="hash_pass" placeholder="Password" required>
            </div>
            <button type="submit" class="btn mt-3">Login</button>
        </form>
        <div style="color: white " class="text-center fs-6">
        <a href="registration.php">Sign up</a>
        <br>
      

        <a href="forgot_pass.php" style="color: red " ><u><b>Forgot Password</b></u></a>

            <br>
            <a style="color: white"><u>## Correct Email is necessary for further authentication ##</u></a>
        </div>
    </div>
    
</body>
</html>