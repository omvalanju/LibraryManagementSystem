<?php

include("database_conn.php");

session_start();
 if(!isset($_SESSION['loggedin'])){
     echo('You Need To Login First!');
     header('refresh:2;url=login.php');
     
 }
  $people_id=$_SESSION['people_id'];
  $book_id=$_POST['book_id'];

$query2 = "SELECT * FROM `books` WHERE books.book_id = '".$book_id."'";
$data2 = mysqli_query($conn, $query2);
$result2 = mysqli_fetch_assoc($data2);
$copies_available= $result2['copies_available'];

$update_copies_available = $copies_available - 1;




$query3 = "SELECT * FROM `people` WHERE people.people_id = '".$people_id."'";
$data3 = mysqli_query($conn, $query3);
$result3 = mysqli_fetch_assoc($data3);
function date_out ($date_in,$time){
  $date_in->modify($time); 
   $date_in = $date_in->format('Y-m-d');
  return $date_in;
}

  if($result3['type']=='student'){
    $due_date=date_out(new DateTime('now'),'+1 month');

  }else{
    $due_date=date_out(new DateTime('now'),'+2 month');

  }


 $sql = "INSERT INTO `borrow_records`(`book_id`, `people_id`, `due_date`) VALUES ('$book_id','$people_id', '$due_date')";
   
 $sql1 = "UPDATE `books` SET `copies_available`='$update_copies_available' WHERE books.book_id = $book_id";

 echo "hi";


$data = mysqli_query($conn,$sql);
$data1 = mysqli_query($conn,$sql1);
if($data){
  ?>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <body class="w3-container w3-auto">

      <div class="w3-panel w3-green">
        <h3>Success!</h3>
        <p>You Successfully added DATA .</p>
      </div>    <?php
  header('refresh:5;url=dashboard.php');
}
else{
  ?>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <body class="w3-container">
  
  <div class="w3-panel w3-red">
    <h3>Danger!</h3>
    <p>Something Went Wrong</p>
  </div>
<?php
}


