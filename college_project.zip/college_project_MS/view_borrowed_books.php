<?php

include("database_conn.php");

session_start();
 if(!isset($_SESSION['loggedin'])){
     echo('You Need To Login First!');
     header('refresh:2;url=login.php');
     
 }
  echo $people_id=$_SESSION['people_id'];

  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>


</head>
<style>
    body{
  border: 1px solid black;
  padding-top: 50px;
  padding-right: 200px;
  padding-bottom: 50px;
  padding-left: 200px;
}
</style>
<body>

<script type="text/javascript">
    $(document).ready(function() {
        $('#jquery-datatable-example-no-configuration').DataTable();
    });
</script>

<?php
$query = "SELECT * FROM borrow_records where borrow_records.people_id='".$people_id."' and borrow_records.return_status='not_returned'";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);





?>
<table class="table" style="border-radius:10px;" cellspacing="3" width="100%">
       <thead>
       <th style="  text-align: center;">Borrowed Books</th>
   </thead>
   <tbody style="text-align: center">
   <?php
   $no=1;
 while($result = mysqli_fetch_assoc($data)){ 
    
    $start_date = strtotime(date("y-m-d"));
    $end_date = strtotime($result['due_date']);
    $days_remaining = ($end_date - $start_date)/60/60/24;

    
    if($days_remaining<=0){
        echo "
        <tr >
            <td>
                <div class='card-center' style='width: 18rem;   background-color: red;'>
                    <img class='card-img-top' src='book.jpg' alt='Card image cap'>
                    <div class='card-body'>
                        <h5 class='card-title'>$no</h5>
                        <p class='card-text'>days_remaining $days_remaining</p>
                        <a href = 'book_return_pay.php?book_id=$result[book_id]&borrow_id=$result[borrow_id]&days_remaining=$days_remaining;'><span class='icon text-black-50'><i style='font-size:20px' class='fas'>&#xf362;</i></span>	&nbsp;<span class='text'>Clear your dues to return the book.</span></a>                            </div>
                </div>
                </td>
        </tr>
    ";
    } else {
        echo "
        <tr >
            <td>
                <div class='card-center' style='width: 18rem;  background-color: green;'>
                    <img class='card-img-top' src='book.jpg' alt='Card image cap'>
                    <div class='card-body'>
                        <h5 class='card-title'>$no</h5>
                        <p class='card-text'>days_remaining $days_remaining</p>
                        <a href = 'book_return.php?book_id=$result[book_id]&borrow_id=$result[borrow_id];'><span class='icon text-black-50'><i style='font-size:20px' class='fas'>&#xf362;</i></span>	&nbsp;<span class='text'>Return book</span></a>                            </div>
                </div>
                </td>
        </tr>
        ";
    }
 
$no++;
 };

 ?>
   </tbody>
   </table>
</body>
</html>