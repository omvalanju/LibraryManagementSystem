<?php
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"]== "POST"){
    include("database_conn.php");
    $email = $_POST["email"];
    $hash_pass = $_POST["hash_pass"];

    $sql = "SELECT * FROM people where email='$email' AND hash_pass='$hash_pass'";
    $data = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($data);
    $result = mysqli_fetch_assoc($data);
    
    $sql1 = "SELECT * FROM people where email='$email'";
    $data1 = mysqli_query($conn, $sql1);
    $num1 = mysqli_num_rows($data1);
    $result1 = mysqli_fetch_assoc($data1);

    $sql2 = "SELECT * FROM people where hash_pass='$hash_pass'";
    $data2 = mysqli_query($conn, $sql2);
    $num2 = mysqli_num_rows($data2);
    $result2 = mysqli_fetch_assoc($data2);

    $hash = '$2y$10$hnQY9vdyZUcwzg2CO7ykf.a4iI5ij4Pi5ZwySwplFJM7AKUNUVssO';
    $valid = password_verify('Password1', $hash);

    echo $valid ? 'Valid' : 'Not valid';

    if($num == 1){
        $login = true;
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        $_SESSION['people_id'] = $result['people_id'];
        header("location: dashboard.php");
    }else if($num1 == 1){
        ?>
        <body style="margin-top: 1%;margin-left: 5%;margin-right: 5%;background-color: rgb(0, 0, 36);align-content: center;">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
            <div style="background-color: rgba(255, 0, 0, 0.7);color:white;" class="card text-center">
          <div s class="card-header">
          <u><b>Mobile Number doesn't match ?</u></b>
          </div>
          <div class="card-body">
            <h5 class="card-title">Mobile Number doesn't match ?</h5>
            <p class="card-text">"Mobile number doesn't match" is a common error message that can occur when attempting to verify a mobile number for an account or service. This error message indicates that the mobile number entered does not match the one associated with the account or service in question.</p>
            <p class="card-text">There are several reasons why a mobile number may not match. For example, the mobile number may have been mistyped or entered incorrectly. Additionally, the mobile number may have changed since it was originally associated with the account or service, or there may be a technical issue preventing the verification process from completing successfully.</p>
            <p class="card-text">If you receive an error message indicating that your mobile number doesn't match, it is advisable to double-check the mobile number and try entering it again. If the problem persists, it may be necessary to update the mobile number associated with the account or service, or to contact customer support for assistance.</p>
            <p class="card-text">It is important to note that mobile numbers are often used as a means of authentication and verification, and are an essential security measure designed to protect personal and sensitive information. As such, it is important to keep your mobile number up to date and to ensure that it is associated with the appropriate accounts and services.</p>
            <p class="card-text">In conclusion, if you receive an error message indicating that your mobile number doesn't match, it is important to verify the accuracy of the mobile number and explore other possible reasons for the error. By taking these steps, you can ensure that your accounts and services remain secure and that your personal information remains protected.</p>
        	
        </div>
        	<button type="submit" onclick="location.href='forgot_pass.php';" class="btn btn-outline-warning">Forgot Mobile Number !</button>

          </div>

        </div>
            </body>
        <?php
    }else if($num2 == 1){
        ?>
        <body style="margin-top: 1%;margin-left: 5%;margin-right: 5%;background-color: rgb(0, 0, 36);align-content: center;">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
            <div style="background-color: rgba(255, 0, 0, 0.7);color:white;" class="card text-center">
          <div s class="card-header">
          <u><b>Email doesn't match ?</u></b>
          </div>
          <div class="card-body">
            <h5 class="card-title">Email doesn't match ?</h5>
            <p class="card-text">"Email doesn't match" is a common error message that can occur when attempting to verify a Email for an account or service. This error message indicates that the Email entered does not match the one associated with the account or service in question.</p>
            <p class="card-text">There are several reasons why a Email may not match. For example, the Email may have been mistyped or entered incorrectly. Additionally, the Email may have changed since it was originally associated with the account or service, or there may be a technical issue preventing the verification process from completing successfully.</p>
            <p class="card-text">If you receive an error message indicating that your Email doesn't match, it is advisable to double-check the Email and try entering it again. If the problem persists, it may be necessary to update the Email associated with the account or service, or to contact customer support for assistance.</p>
            <p class="card-text">It is important to note that Emails are often used as a means of authentication and verification, and are an essential security measure designed to protect personal and sensitive information. As such, it is important to keep your Email up to date and to ensure that it is associated with the appropriate accounts and services.</p>
            <p class="card-text">In conclusion, if you receive an error message indicating that your Email doesn't match, it is important to verify the accuracy of the Email and explore other possible reasons for the error. By taking these steps, you can ensure that your accounts and services remain secure and that your personal information remains protected.</p>
        	
        </div>
        	<button type="submit" onclick="location.href='forgot_pass.php';" class="btn btn-outline-warning">Forgot Email !</button>

          </div>

        </div>
            </body>
        <?php
    }else{
        ?>
 <body style="margin-top: 1%;margin-left: 5%;margin-right: 5%;background-color: rgb(0, 0, 36);align-content: center;">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
            <div style="background-color: rgba(255, 0, 0, 0.7);color:white;" class="card text-center">
          <div s class="card-header">
          <u><b>Both Email and Mobile Number doesn't match ?</u></b>
          </div>
          <div class="card-body">
            <h5 class="card-title">Both Email and Mobile Number doesn't match ?</h5>
            <p class="card-text">"Both Email and Mobile number doesn't match" is a common error message that can occur when attempting to verify a Both Email and mobile number for an account or service. This error message indicates that the Both Email and mobile number entered does not match the one associated with the account or service in question.</p>
            <p class="card-text">There are several reasons why a Both Email and mobile number may not match. For example, the Both Email and mobile number may have been mistyped or entered incorrectly. Additionally, the Both Email and mobile number may have changed since it was originally associated with the account or service, or there may be a technical issue preventing the verification process from completing successfully.</p>
            <p class="card-text">If you receive an error message indicating that your Both Email and mobile number doesn't match, it is advisable to double-check the Both Email and mobile number and try entering it again. If the problem persists, it may be necessary to update the Both Email and mobile number associated with the account or service, or to contact customer support for assistance.</p>
            <p class="card-text">It is important to note that Both Email and mobile numbers are often used as a means of authentication and verification, and are an essential security measure designed to protect personal and sensitive information. As such, it is important to keep your Both Email and mobile number up to date and to ensure that it is associated with the appropriate accounts and services.</p>
            <p class="card-text">In conclusion, if you receive an error message indicating that your Both Email and mobile number doesn't match, it is important to verify the accuracy of the Both Email and mobile number and explore other possible reasons for the error. By taking these steps, you can ensure that your accounts and services remain secure and that your personal information remains protected.</p>
        	
        </div>
        	<button type="submit" onclick="location.href='forgot_pass.php';" class="btn btn-outline-warning">Forgot Both Email and Mobile Number !</button>

          </div>

        </div>
            </body>
        <?php
    }
}
?>
