<?php
 session_start();
 if(!isset($_SESSION['loggedin'])){
     echo('You Need To Login First!');
     header('Location: login.php');
     
 }
  $people_id=$_SESSION['people_id'];
include("database_conn.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script type="text/javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>


</head>
<style>
    body{
  border: 1px solid black;
  background-color: lightblue;
  padding-top: 50px;
  padding-right: 200px;
  padding-bottom: 50px;
  padding-left: 200px;
}
</style>
<body>

<script type="text/javascript">
    $(document).ready(function() {
        $('#jquery-datatable-example-no-configuration').DataTable();
    });
</script>

<?php
$query = "SELECT * FROM books ";
$data = mysqli_query($conn, $query);



$total = mysqli_num_rows($data);



?>
<button type="button" class="btn btn-secondary" onclick="document.location='view_borrowed_books.php'">View Borrowed Books</button>
<button type="button" class="btn btn-secondary" onclick="document.location='logout.php'">Logout From Books!</button>

<br>

<table id="jquery-datatable-example-no-configuration" class="table" style="border-radius:10px;" cellspacing="3" width="100%">
       <thead>
       <th width="2%">SR. No.</th>
       <th width="5%">Book Image</th>
       <th width="3%">Book Name</th>
       <th width="5%">Author Name</th>
       <th width="5%">ISBN</th>
       <th width="5%">Copies Available</th>
       <th width="10%">Operation</th>
   </thead>
   <tbody>
   <?php
   $no=1;
 while($result = mysqli_fetch_assoc($data)){ 
  echo "

        <tr>
            <td>".$no."</td>
            <td style='$son'><img src='book.jpg' height='100' class='w3-hover-opacity' onclick='onClick(this)' width='100' alt='No Picture uploaded'></td>
            <td>".$result['book_title']."</td>
            <td>".$result['author_name']."</td>
            <td>".$result['ISBN']."</td>
            <td>".$result['copies_available']."</td>
            <td><a href = 'borrow_record.php?book_id=$result[book_id]'><span class='icon text-black-50'><i style='font-size:20px' class='fas'>&#xf362;</i></span>	&nbsp;<span class='text'>Borrow book</span></a>        </tr>
            </td>
 
";
$no++;
 };

 ?>
   </tbody>
   </table>
</body>
</html>